﻿namespace shoppingAPP.Models
{
    public class Products
    {
        public int pId { get; set; }
        public string pName { get; set; }
        public double pPrice { get; set; }
        public bool pIsInStock { get; set; }
        public string pCategory { get; set; }
        public string pImageURL { get; set; }

        //In memory collection of data - Data structure
        static List<Products> pList = new List<Products>()
        {
            new Products(){ pId=101, pName="Pepsi", pCategory="Cold-Drink", pIsInStock=true, pPrice=50, pImageURL="pepsi.jpg"},
            new Products(){ pId=102, pName="Iphone", pCategory="Electronics", pIsInStock=true, pPrice=500, pImageURL="iphone.jpg"},
            new Products(){ pId=103, pName="Red-Tape", pCategory="Shoe", pIsInStock=false, pPrice=1200,pImageURL="redtape.jpg"},
            new Products(){ pId=104, pName="Appy", pCategory="Cold-Drink", pIsInStock=true, pPrice=80,pImageURL="appy.jpg"},
            new Products(){ pId=105, pName="Maggie", pCategory="Fast-Food", pIsInStock=false, pPrice=90,pImageURL=""},
            new Products(){ pId=106, pName="Pasta", pCategory="Fast-Food", pIsInStock=true, pPrice=120,pImageURL=""},
            new Products(){ pId=107, pName="Air Pods", pCategory="Electronics", pIsInStock=true, pPrice=12000, pImageURL = ""},
        };

        public List<Products> GetProductsList()
        {
            return pList;
        }

        public Products GetProductById(int id)
        {
            var p = pList.Find(pr => pr.pId == id);
            if (p != null)
            {
                return p;
            }
            throw new Exception("Product Not Found ");
        }

        public string DeleteProduct(int id)
        {
            var p = pList.Find(pr => pr.pId == id);
            if (p != null)
            {
                pList.Remove(p);
                return "Product Removed Successfully";
            }
            throw new Exception("Product Not Found ");
        }

        public string AddProduct(Products newProduct)
        {
            //do some validations here, like pName to be minimum 3 characters etc...and throw exception accordingly
            //check fi the product id is already present, throw an exception, do not add it to the list

            pList.Add(newProduct);
            return "Product Added Successfully";
        }


        //some more methods here for search, sort, add, update, delete etc... we will add it soon

    }
}
