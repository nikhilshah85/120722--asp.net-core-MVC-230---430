﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;

namespace aspnetMVC_identity.Areas.Identity.Data;

// Add profile data for application users by adding properties to the aspnetMVC_identityUser class
public class aspnetMVC_identityUser : IdentityUser
{
}

