using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using aspnetMVC_identity.Data;
using aspnetMVC_identity.Areas.Identity.Data;

var builder = WebApplication.CreateBuilder(args);
var connectionString = builder.Configuration.GetConnectionString("aspnetMVC_identityContextConnection") ?? throw new InvalidOperationException("Connection string 'aspnetMVC_identityContextConnection' not found.");

builder.Services.AddDbContext<aspnetMVC_identityContext>(options =>
    options.UseSqlServer(connectionString));

builder.Services.AddDefaultIdentity<aspnetMVC_identityUser>(options => options.SignIn.RequireConfirmedAccount = true)
    .AddEntityFrameworkStores<aspnetMVC_identityContext>();

// Add services to the container.
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
app.UseAuthentication();;

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
