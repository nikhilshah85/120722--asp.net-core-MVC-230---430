﻿using System.Net.Http;

namespace conume_WEBAPI.Models
{
    public class Albums
    {
        public int userId  { get; set; }
        public int Id { get; set; }
        public string title { get; set; }

        public List<Albums> GetAlbums()
        {
            string url = "https://jsonplaceholder.typicode.com/albums";
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Clear(); //every browser, has adefault format
            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

            var callService = client.GetAsync(url);
            var response = callService.Result;

            List<Albums> data = new List<Albums>();
            if (response.IsSuccessStatusCode)
            {
                var read = response.Content.ReadAsAsync<List<Albums>>();
                read.Wait();
                data = read.Result;
                return data;
            }
            throw new Exception("Failed to get the data");
        }
    }
}
