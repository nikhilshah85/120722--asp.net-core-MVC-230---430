﻿using Microsoft.AspNetCore.Mvc;
using shoppingAPP.Models;
namespace shoppingAPP.Controllers
{
    public class ProductController : Controller
    {
        Products pObj = new Products();

       public IActionResult DisplayProducts()
        {
            ViewBag.products = pObj.GetProductsList();
            return View();
        }

        [HttpGet]
        public IActionResult SearchProduct()
        {
            ViewBag.hasData = false;
            ViewBag.errMessage = "";
            return View();
        }
        [HttpPost]
        public IActionResult SearchProduct(int productId)
        {            
            try
            {
                ViewBag.product = pObj.GetProductById(productId);
                ViewBag.hasData = true;
                ViewBag.errMessage = "No Error";
            }
            catch(Exception es)
            {
                ViewBag.errMessage = es.Message;
            }

            return View();
        }
    }
}
